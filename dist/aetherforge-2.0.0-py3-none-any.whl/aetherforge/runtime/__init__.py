'''
Game runtime and renderer.
'''
