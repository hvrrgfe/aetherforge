'''
Demo projects.
'''
