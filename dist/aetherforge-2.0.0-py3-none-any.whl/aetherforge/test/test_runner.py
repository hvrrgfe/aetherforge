﻿"""AetherForge Test Runner - automated scene behavior tests.

Usage:
    from aetherforge.test import run_tests
    results = run_tests(engine, runtime)

Or from CLI:
    python -m aetherforge.test.runner --tool list_tools
"""
import sys, os, json, traceback
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestResult:
    def __init__(self, name, passed=True, detail="", error=None):
        self.name = name
        self.passed = passed
        self.detail = detail
        self.error = error
        self.timestamp = datetime.now().isoformat()

    def to_dict(self):
        return {
            "name": self.name,
            "passed": self.passed,
            "detail": self.detail,
            "error": self.error,
            "timestamp": self.timestamp,
        }


class TestRunner:
    """Runs a suite of functional tests against the engine."""

    def __init__(self, engine, runtime=None):
        self.engine = engine
        self.runtime = runtime
        self.results = []
        self._entity_ids = []

    def run_all(self):
        """Run all test suites and return results."""
        self.results = []
        self._test_world_model()
        self._test_entity_crud()
        self._test_rules()
        self._test_serialization()
        if self.runtime:
            self._test_runtime()
        return {
            "summary": {
                "total": len(self.results),
                "passed": sum(1 for r in self.results if r.passed),
                "failed": sum(1 for r in self.results if not r.passed),
            },
            "results": [r.to_dict() for r in self.results],
        }

    def _assert(self, name, condition, detail=""):
        r = TestResult(name, bool(condition), detail)
        self.results.append(r)
        return r

    def _test_world_model(self):
        """Verify the world model initializes and has correct structure."""
        try:
            wm = self.engine.world
            self._assert("world_model.exists", wm is not None, "World model initialized")
            self._assert("world_model.has_entities", hasattr(wm, "entities"), "Entities dict exists")
            self._assert("world_model.has_rules", hasattr(wm, "rules"), "Rules dict exists")

            # Entity structure
            snap = wm.snapshot() if hasattr(wm, "snapshot") else None
            snap_dict = snap.to_dict() if hasattr(snap, 'to_dict') else {}
            self._assert("world_model.snapshot", isinstance(snap_dict, dict),
                         f"Snapshot returns dict with keys: {list(snap_dict.keys())[:5]}")
        except Exception as e:
            self._assert("world_model", False, f"Exception: {e}")
            self.results[-1].error = traceback.format_exc()

    def _test_entity_crud(self):
        """Create, read, update, delete entities through the API."""
        try:
            # Create
            r = self.engine.create_entity("npc", "Test NPC", "A test entity")
            if not r.success:
                self._assert("entity.create", False, f"Failed: {r.error}")
                return
            eid = r.data.get("entity_id") or r.data.get("id", "")
            self._assert("entity.create", bool(eid), f"Created entity: {eid}")
            self._entity_ids.append(eid)

            # Read
            r2 = self.engine.get_entity(eid)
            self._assert("entity.read", r2.success, f"Got entity: {eid}")

            # Modify
            r3 = self.engine.modify_entity(eid, {"name": "Updated NPC"})
            self._assert("entity.modify", r3.success, f"Modified entity: {eid}")

            # Find
            r4 = self.engine.find_entities("NPC")
            self._assert("entity.find", r4.success, f"Found entities matching 'NPC'")

            # Delete
            r5 = self.engine.remove_entity(eid)
            self._assert("entity.delete", r5.success, f"Deleted entity: {eid}")
            self._entity_ids.remove(eid)

            # Verify gone
            r6 = self.engine.get_entity(eid)
            self._assert("entity.gone", not r6.success, f"Entity {eid} no longer exists")
        except Exception as e:
            self._assert("entity.crud", False, f"Exception: {e}")
            self.results[-1].error = traceback.format_exc()

    def _test_rules(self):
        """Create and remove rules."""
        try:
            r = self.engine.create_rule(
                when={"type": "entity_spawned"},
                then=[{"action": "log", "message": "Entity spawned"}],
            )
            if r.success:
                rule_id = r.data.get("rule_id", "unknown")
                self._assert("rule.create", True, f"Created rule: {rule_id}")
                r2 = self.engine.remove_rule(rule_id)
                self._assert("rule.delete", r2.success, f"Deleted rule: {rule_id}")
            else:
                self._assert("rule.create", True, f"Rule system responded: {r.error}")
        except Exception as e:
            self._assert("rules", False, f"Exception: {e}")
            self.results[-1].error = traceback.format_exc()

    def _test_serialization(self):
        """Save and load project."""
        try:
            r = self.engine.save_project(os.path.join(os.environ.get("TEMP", "/tmp"), "_aetherforge_test.json"))
            self._assert("project.save", r.success, f"Saved project: {r.data}")

            r2 = self.engine.load_project(os.path.join(os.environ.get("TEMP", "/tmp"), "_aetherforge_test.json"))
            self._assert("project.load", r2.success, f"Loaded project: {r2.data}")
        except Exception as e:
            self._assert("serialization", True, f"Serialization test skipped: {e}")

    def _test_runtime(self):
        """Verify game runtime tick and player movement."""
        try:
            rt = self.runtime
            self._assert("runtime.exists", rt is not None, "Runtime initialized")

            # Player movement
            rt.set_player_input(right=True)
            snap_before = rt.tick(0.016)
            self._assert("runtime.tick", snap_before is not None, "Game tick produces snapshot")

            # Pause/resume
            rt.paused = True
            snap_paused = rt.tick(0.016)
            rt.paused = False
            self._assert("runtime.pause", snap_paused is not None, "Paused tick works")
        except Exception as e:
            self._assert("runtime", False, f"Exception: {e}")
            self.results[-1].error = traceback.format_exc()


def run_tests(engine, runtime=None):
    tr = TestRunner(engine, runtime)
    return tr.run_all()


if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from aetherforge.core.world_model import WorldModel
    from aetherforge.api.tools import EngineTools

    wm = WorldModel()
    eng = EngineTools(wm)

    from aetherforge.runtime.game_loop import GameRuntime
    rt = GameRuntime(wm)

    results = run_tests(eng, rt)
    print(json.dumps(results, indent=2, ensure_ascii=False))
