# -*- coding: utf-8 -*-
"""Tests for CLI and Config modules."""
import sys, os, json
from datetime import datetime

class T:
    def __init__(self, n, p=True, d="", e=None):
        self.name=n; self.passed=p; self.detail=d; self.error=e
        self.t=datetime.now().isoformat()
    def to_dict(self):
        return {'name':self.name,'passed':self.passed,'detail':self.detail,'error':self.error,'timestamp':self.t}

class C:
    def __init__(self):
        self.r=[]
    def chk(self,n,c,d=""):
        t=T(n,c,d); self.r.append(t); return t
    def run(self):
        self.r=[]; self.t1(); self.t2()
        return {"summary":{"total":len(self.r),"passed":sum(1 for x in self.r if x.passed),"failed":sum(1 for x in self.r if not x.passed)},"results":[x.to_dict() for x in self.r]}
    def t1(self):
        try:
            from aetherforge.config import get_config, CONFIG_DIR, MODELS_DIR, validate_torch
            c=get_config()
            self.chk('v',c.version=='2.0.0')
            self.chk('p',c.physics.enabled)
            self.chk('a',c.audio.enabled)
            self.chk('cd','.' in str(CONFIG_DIR))
            self.chk('md','models' in str(MODELS_DIR))
            self.chk('td','version' in c.to_dict())
            ok,_=validate_torch()
            self.chk('torch',type(ok)==bool)
        except Exception as e:
            import traceback as tb
            self.chk("cfg",False,"E:"+str(e))
            self.r[-1].error=tb.format_exc()
    def t2(self):
        try:
            import aetherforge.cli as cli
            self.chk('cli',callable(cli.main))
            self.chk('cli_has',hasattr(cli,'main'))
        except Exception as e:
            import traceback as tb
            self.chk("cli",False,"E:"+str(e))
            self.r[-1].error=tb.format_exc()

if __name__=="__main__":
    t=C(); r=t.run()
    print(json.dumps(r,indent=2,ensure_ascii=False))
    sys.exit(1 if r["summary"]["failed"]>0 else 0)
