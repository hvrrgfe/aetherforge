"""AetherForge MCP Server 集成测试

启动 Flask 服务器 -> 通过 HTTP API 调用工具 -> 验证端到端流程。

运行:
    python -m aetherforge.test.test_integration_mcp
"""
import sys, os, json, threading, time, urllib.request, urllib.error

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

API_BASE = "http://127.0.0.1:17890"


class IntegrationTestRunner:
    def __init__(self):
        self.server = None
        self.thread = None
        self.passed = 0
        self.failed = 0
        self.results = []

    def _start_server(self):
        from aetherforge.main import AetherForgeServer
        import flask

        self.server = AetherForgeServer(host="127.0.0.1", port=17890)
        original_run = flask.Flask.run

        def _run_quiet(app, *a, **kw):
            kw["debug"] = False
            kw["use_reloader"] = False
            kw["threaded"] = True
            t = threading.Thread(target=lambda: original_run(app, *a, **kw), daemon=True)
            t.start()

        flask.Flask.run = _run_quiet
        self.server.start()

    def _api_call(self, tool_name, **kwargs):
        data = json.dumps(kwargs).encode("utf-8")
        req = urllib.request.Request(
            f"{API_BASE}/api/tools/{tool_name}",
            data=data, headers={"Content-Type": "application/json"}, method="POST",
        )
        try:
            resp = urllib.request.urlopen(req, timeout=10)
            return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            return json.loads(body) if body else {"success": False, "error": f"HTTP {e.code}"}
        except Exception as ex:
            return {"success": False, "error": str(ex)}

    def _api_get(self, path):
        try:
            resp = urllib.request.urlopen(f"{API_BASE}{path}", timeout=10)
            return json.loads(resp.read().decode("utf-8"))
        except Exception as ex:
            return {"success": False, "error": str(ex)}

    def assert_ok(self, name, result, detail=""):
        ok = result.get("success", False)
        status = "PASS" if ok else "FAIL"
        print(f"  [{status}] {name}: {detail or ok}")
        self.results.append({"name": name, "passed": ok, "detail": detail})
        if ok:
            self.passed += 1
        else:
            self.failed += 1

    def run(self):
        print("=" * 60)
        print("AetherForge MCP Server 集成测试")
        print("=" * 60)

        print("\n[1/6] 启动服务器...")
        self._start_server()
        time.sleep(1.5)

        print("\n[2/6] 健康检查...")
        tools_resp = self._api_get("/api/tools")
        self.assert_ok("GET /api/tools", tools_resp,
                       "返回 %d 个工具" % len(tools_resp.get("data", {}).get("tools", [])))
        summary = self._api_get("/api/summary")
        self.assert_ok("GET /api/summary", {"success": True},
                       "summary=%s" % json.dumps(summary)[:100])

        print("\n[3/6] 实体 CRUD...")
        r1 = self._api_call("create_entity", semantic_type="npc",
                            name="Test NPC", description="集成测试实体")
        self.assert_ok("create_entity", r1)
        eid = r1.get("data", {}).get("entity_id", "") if r1.get("success") else ""

        if eid:
            print("    创建实体: %s" % eid)
            r2 = self._api_call("get_entity", entity_id=eid)
            self.assert_ok("get_entity", r2, "entity=%s" % eid)
            r3 = self._api_call("modify_entity", entity_id=eid,
                                changes={"name": "Updated NPC"})
            self.assert_ok("modify_entity", r3)
            r4 = self._api_call("find_entities", query="type:npc")
            self.assert_ok("find_entities", r4)

        print("\n[4/6] 规则系统...")
        r = self._api_call("create_rule", when={"type": "entity_spawned"},
                           then=[{"action": "log", "message": "Spawned"}])
        self.assert_ok("create_rule", r)
        if r.get("success"):
            rule_id = r.get("data", {}).get("rule_id", "")
            r2 = self._api_call("remove_rule", rule_id=rule_id)
            self.assert_ok("remove_rule", r2)

        print("\n[5/6] 世界观察...")
        obs = self._api_get("/api/observe")
        self.assert_ok("observe", obs,
                       "entities=%d" % len(obs.get("data", {}).get("entities", {})))
        game = self._api_get("/api/game-state")
        self.assert_ok("game-state", {"success": game is not None},
                       "entities=%d" % len(game.get("entities", [])))

        print("\n[6/6] 错误处理...")
        err = self._api_call("nonexistent_tool_xyz")
        self.assert_ok("unknown_tool_returns_404",
                       {"success": not err.get("success")},
                       "错误: %s" % err.get("error", "")[:60])

        total = self.passed + self.failed
        print("\n" + "=" * 60)
        print("结果: %d 个测试, %d 通过, %d 失败" % (total, self.passed, self.failed))
        print("通过率: %d%%" % (self.passed / total * 100) if total > 0 else "无测试")
        print("=" * 60)
        return {"total": total, "passed": self.passed, "failed": self.failed}


if __name__ == "__main__":
    runner = IntegrationTestRunner()
    result = runner.run()
    sys.exit(1 if result["failed"] > 0 else 0)