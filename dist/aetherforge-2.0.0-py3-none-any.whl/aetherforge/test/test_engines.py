﻿"""AetherForge Engine Module Tests --- Audio / 3D / AI engines.

Tests high-risk modules (audio, 3D, AI image/music gen) without
external dependencies (pygame, torch, diffusers, audiocraft).
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from datetime import datetime


class TestResult:
    def __init__(self, name, passed=True, detail="", error=None):
        self.name = name
        self.passed = passed
        self.detail = detail
        self.error = error
        self.timestamp = datetime.now().isoformat()
    def to_dict(self):
        return {"name": self.name, "passed": self.passed, "detail": self.detail,
                "error": self.error, "timestamp": self.timestamp}


class EngineModuleTester:
    def __init__(self):
        self.results = []

    def _assert(self, name, condition, detail=""):
        r = TestResult(name, bool(condition), detail)
        self.results.append(r)
        return r

    def run_all(self):
        self.results = []
        self._test_3d_scene_graph()
        self._test_audio_engine_no_pygame()
        self._test_image_gen_no_torch()
        self._test_music_gen_no_torch()
        self._test_model_manager()
        return {"summary": {"total": len(self.results),
                "passed": sum(1 for r in self.results if r.passed),
                "failed": sum(1 for r in self.results if not r.passed)},
                "results": [r.to_dict() for r in self.results]}

    def _test_3d_scene_graph(self):
        try:
            from aetherforge.renderer import SceneGraph3D, MeshData, Transform3D, Vector3, Light3D, Camera3D
            from aetherforge.core.world_model import WorldModel
            wm = WorldModel()
            sg = SceneGraph3D(wm)
            self._assert("3d.init", sg is not None, "SceneGraph3D created")
            self._assert("3d.empty", len(sg.get_3d_state()["entities"]) == 0, "Empty scene has 0 entities")
            sg.set_mesh("ent_1", MeshData(geometry="box", color="#ff0000"))
            sg.set_transform("ent_1", Transform3D(position=Vector3(1, 2, 3)))
            self._assert("3d.mesh", len(sg.get_3d_state()["entities"]) == 1, "Entity added")
            idx = sg.add_light(Light3D(light_type="directional"))
            self._assert("3d.light", idx == 0, "Light at index 0")
            sg.set_camera(Camera3D(fov=45, position=Vector3(0, 0, 20)))
            self._assert("3d.cam", sg.get_3d_state()["camera"]["fov"] == 45, "Camera FOV=45")
            sg.set_mesh("ent_2", {"geometry": "sphere", "color": "#00ff00"})
            self._assert("3d.dict", len(sg.get_3d_state()["entities"]) == 2, "Dict API works")
            self._assert("3d.json", "entities" in json.loads(sg.to_json()), "JSON serialization works")
        except Exception as e:
            import traceback
            self._assert("3d.suite", False, f"Exception: {e}")
            self.results[-1].error = traceback.format_exc()

    def _test_audio_engine_no_pygame(self):
        try:
            import builtins
            orig = builtins.__import__
            def mock_import(name, *a, **kw):
                if name == "pygame":
                    raise ImportError("mock: no pygame")
                return orig(name, *a, **kw)
            builtins.__import__ = mock_import
            from aetherforge.runtime.audio import AudioEngine
            audio = AudioEngine()
            audio.init()
            self._assert("audio.disabled", audio._disabled, "Audio disabled when pygame missing")
            self._assert("audio.play_err", audio.play_sound("x").get("error") == "Audio disabled", "Play error")
            self._assert("audio.music_err", audio.play_music("x").get("error") == "Audio disabled", "Music error")
            self._assert("audio.state", audio.get_state()["disabled"] is True, "State shows disabled")
            builtins.__import__ = orig
        except Exception as e:
            import traceback
            self._assert("audio.suite", False, f"Exception: {e}")
            self.results[-1].error = traceback.format_exc()
        finally:
            try:
                builtins.__import__ = orig
            except:
                pass

    def _test_image_gen_no_torch(self):
        try:
            from aetherforge.ai_engines.image_gen import ImageGenEngine
            img = ImageGenEngine()
            self._assert("img.state", "loaded" in img.get_state(), "State created")
            models = img.list_available_models()
            self._assert("img.models", len(models) >= 7, f"{len(models)} image models")
            sel = img.select_model("sd-1.5")
            self._assert("img.select", isinstance(sel, dict), "select_model returns dict")
            res = img.generate("test")
            self._assert("img.gen_err", "error" in res, "Generate returns error when not loaded")
            self._assert("img.assets", isinstance(img.list_assets(), list), "list_assets returns list")
        except Exception as e:
            import traceback
            self._assert("img.suite", False, f"Exception: {e}")
            self.results[-1].error = traceback.format_exc()

    def _test_music_gen_no_torch(self):
        try:
            from aetherforge.ai_engines.music_gen import MusicGenEngine
            mus = MusicGenEngine()
            self._assert("mus.state", "loaded" in mus.get_state(), "State created")
            models = mus.list_available_models()
            self._assert("mus.models", len(models) >= 5, f"{len(models)} music models")
            sel = mus.select_model("musicgen-medium")
            self._assert("mus.select", isinstance(sel, dict), "select_model returns dict")
            res = mus.generate_music("test")
            self._assert("mus.gen_err", "error" in res, "Generate returns error")
            res2 = mus.generate_sound_effect("sfx")
            self._assert("mus.sfx_err", "error" in res2, "SFX returns error")
            self._assert("mus.assets", isinstance(mus.list_assets(), list), "list_assets returns list")
        except Exception as e:
            import traceback
            self._assert("mus.suite", False, f"Exception: {e}")
            self.results[-1].error = traceback.format_exc()

    def _test_model_manager(self):
        try:
            from aetherforge.tools.model_manager import model_mgr
            im = model_mgr.list_models("image")
            self._assert("mgr.images", len(im) >= 7, f"{len(im)} image models")
            mm = model_mgr.list_models("music")
            self._assert("mgr.music", len(mm) >= 5, f"{len(mm)} music models")
            info = model_mgr.model_info("anything-v5")
            self._assert("mgr.info", info.get("success"), "Model info")
            dl = model_mgr.download("nonexistent_model_xyz")
            self._assert("mgr.bad_dl", not dl.get("success"), "Unknown model fails")
            self._assert("mgr.progress", isinstance(model_mgr.download_progress(), list), "progress returns list")
        except Exception as e:
            import traceback
            self._assert("mgr.suite", False, f"Exception: {e}")
            self.results[-1].error = traceback.format_exc()


if __name__ == "__main__":
    tester = EngineModuleTester()
    results = tester.run_all()
    print(json.dumps(results, indent=2, ensure_ascii=False))
    sys.exit(1 if results["summary"]["failed"] > 0 else 0)
