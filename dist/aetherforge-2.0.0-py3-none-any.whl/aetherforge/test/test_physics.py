"""AetherForge Physics Engine Smoke Test

Tests that physics engine initializes, bodies can be added/removed,
and basic operations (gravity, force, raycast) return without error.

Run: python -m aetherforge.test.test_physics
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def test_physics():
    passed = failed = 0
    results = []

    def check(name, ok, detail=""):
        nonlocal passed, failed
        if ok:
            passed += 1
            status = "PASS"
        else:
            failed += 1
            status = "FAIL"
        print(f"  [{status}] {name}: {detail or ok}")
        results.append({"name": name, "passed": ok, "detail": detail})

    try:
        from aetherforge.core.world_model import WorldModel
        from aetherforge.api.engine_v2 import EngineToolsV2
    except ImportError as e:
        print(f"  [FAIL] import: {e}")
        return {"total": 1, "passed": 0, "failed": 1}

    wm = WorldModel()
    eng = EngineToolsV2(wm)

    # 1. Init physics
    r = eng.init_physics()
    check("init_physics", r.success, f"initialized={r.data.get('initialized')}")

    # 2. Create entity + add physics body
    r2 = eng.create_entity("object", "Box", "Physics test box")
    check("create_entity", r2.success)
    if r2.success:
        eid = r2.data["entity_id"]
        r3 = eng.add_physics_body(eid, shape="box", width=32, height=32, mass=1.0)
        check("add_physics_body", r3.success, f"body={eid}")

        # 3. Get physics info
        r4 = eng.get_physics_info(eid)
        check("get_physics_info", r4.success, f"info={json.dumps(r4.data)[:80] if r4.success else r4.error}")

        # 4. Apply force
        r5 = eng.apply_force(eid, fx=100.0, fy=0.0)
        check("apply_force", r5.success)

        # 5. Set gravity
        r6 = eng.set_gravity(0.0, 500.0)
        check("set_gravity", r6.success)

        # 6. Remove physics body
        r7 = eng.remove_physics_body(eid)
        check("remove_physics_body", r7.success)

        # 7. Clean up entity
        eng.remove_entity(eid)

    # 8. Ray cast (on empty world, should return no hit)
    r8 = eng.ray_cast(0, 0, 100, 100)
    check("ray_cast", r8.success, f"hit={r8.data.get('hit_entity_id')}")

    total = passed + failed
    print(f"\n  Result: {passed}/{total} passed, {failed} failed")
    return {"total": total, "passed": passed, "failed": failed}


if __name__ == "__main__":
    print("=" * 50)
    print("AetherForge Physics Smoke Test")
    print("=" * 50)
    result = test_physics()
    sys.exit(1 if result["failed"] > 0 else 0)